define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadAccounts extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callRestAccountsGetallAccountsResult = await Actions.callRest(context, {
        endpoint: 'accounts/getall_accounts',
        uriParams: {
          fields: 'PartyId',
          onlyData: true,
        },
      });

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.getAccountADP,
      });
    }

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.arg1 
     */
    async logThis(context, { arg1 }) {
      const { $page, $flow, $application } = context;
      console.log("**" + JSON.stringify(arg1));
    }

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.arr 
     */
    async createVar(context, { arr }) {
      const { $page, $flow, $application } = context;
     
      for (let i = 0; i < arr.length; i++) {
        console.log("**Block statement execution no." + arr[i].PartyId);
      }
    }
  }

  return loadAccounts;
});
