define([], () => {
  'use strict';

  class LayoutModule {
  }

  return LayoutModule;
});
