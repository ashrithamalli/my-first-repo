define([], () => {
  'use strict';

  class DataDescriptionModule {
  }

  return DataDescriptionModule;
});
